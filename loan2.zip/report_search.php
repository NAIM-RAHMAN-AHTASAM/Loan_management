<?php include 'header.php'; ?>


<center>
	<form method="POST" style="text-align:center" action="print_report.php">

		<h2 style="font-size:150%;"> Search By Account Number:</h2>
		<input type="text" style="font-size:150%;" name="acc_number">
		<br><br>
		<button class="button" ><b><big>Search</big></button>
		<br><br>
	</form>
</center>

<?php include 'footer.php'; ?>
