<?php include 'header.php'; ?>


	<form action ="src.php" method="POST" style="text-align:center">

    <center>    <br><br>               

      <input type="text" style="font-size:150%;" name="search_id" placeholder="Search by Member ID...">
      <br><br>

      <button class="button" ><b><big>Search</big></button>
      <br><br>

    </center>
</form>
<div style="padding: 60px;">
<center>


</center>
</div>


<?php include 'footer.php'; ?>
